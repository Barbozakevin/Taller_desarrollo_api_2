const bcrypt = require('bcryptjs');
const db = require('../src/db/database');
const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const password = process.env.ADMIN_PASSWORD || '';
if (!email || password.length < 10) {
  console.error('Define ADMIN_EMAIL y ADMIN_PASSWORD (mínimo 10 caracteres) en .env antes de inicializar.');
  process.exit(1);
}
const hash = bcrypt.hashSync(password, 12);
db.prepare(`INSERT INTO users (email, password_hash) VALUES (?, ?)
  ON CONFLICT(email) DO UPDATE SET password_hash = excluded.password_hash`)
  .run(email, hash);
console.log(`Cuenta de prueba inicializada para ${email}; la contraseña quedó almacenada como hash.`);
