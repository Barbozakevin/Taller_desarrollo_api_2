// Verificación reproducible: inicia y reinicia la API para comprobar persistencia real.
require('dotenv').config();
const path = require('node:path');
const { spawn } = require('node:child_process');
const jwt = require('jsonwebtoken');
const { jwtSecret } = require('../src/config');
const base = `http://127.0.0.1:${process.env.PORT || 3000}`;
const email = process.env.ADMIN_EMAIL;
const password = process.env.ADMIN_PASSWORD;
const serverFile = path.join(__dirname, '..', 'src', 'server.js');
if (!email || !password) throw new Error('Configura ADMIN_EMAIL y ADMIN_PASSWORD en .env.');
let server = null;
async function request(pathname, { method = 'GET', body, token, rawToken } = {}) {
  const headers = { 'content-type': 'application/json' };
  if (token) headers.authorization = `Bearer ${token}`;
  if (rawToken) headers.authorization = `Bearer ${rawToken}`;
  const response = await fetch(base + pathname, { method, headers, body: body ? JSON.stringify(body) : undefined });
  return { status: response.status, body: await response.json().catch(() => null) };
}
async function ready() {
  for (let i = 0; i < 50; i++) {
    try { if ((await fetch(`${base}/health`)).ok) return; } catch {}
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  throw new Error('La API no inició dentro del tiempo esperado.');
}
function startServer() {
  server = spawn(process.execPath, [serverFile], { cwd: path.join(__dirname, '..'), stdio: 'ignore' });
  return ready();
}
async function stopServer() {
  if (!server) return;
  server.kill('SIGTERM');
  await new Promise(resolve => server.once('exit', resolve));
  server = null;
}
(async () => {
  // Para que el reinicio sea real y controlado, no se conecta a un servidor externo.
  try {
    const running = await fetch(`${base}/health`, { signal: AbortSignal.timeout(300) });
    if (running.ok) throw new Error('Detén el servidor que ya ocupa el puerto y vuelve a ejecutar npm run verify.');
  } catch (error) {
    if (error.message.startsWith('Detén el servidor')) throw error;
    await startServer();
  }
  const login = await request('/auth/login', { method: 'POST', body: { email, password } });
  if (login.status !== 200 || !login.body?.token) throw new Error('Login no obtuvo token.');
  const token = login.body.token;
  const denied = await request('/libros');
  if (denied.status !== 401) throw new Error('La ruta sin token no devolvió 401.');
  const invalid = await request('/libros', { rawToken: 'token-invalido' });
  if (invalid.status !== 401) throw new Error('La ruta con token inválido no devolvió 401.');
  const badLogin = await request('/auth/login', { method: 'POST', body: { email, password: 'incorrecta' } });
  if (badLogin.status !== 401) throw new Error('Credenciales incorrectas no devolvieron 401.');
  const missing = await request('/libros', { method: 'POST', token, body: { titulo: 'Incompleto' } });
  if (missing.status !== 400) throw new Error('Falta de campo obligatorio no devolvió 400.');
  const created = await request('/libros', { method: 'POST', token, body: { titulo: 'El principito', autor: 'Antoine de Saint-Exupéry', anio: 1943 } });
  if (created.status !== 201) throw new Error(`Create falló: ${created.status}`);
  const id = created.body.id;
  const list = await request('/libros', { token });
  const one = await request(`/libros/${id}`, { token });
  const updated = await request(`/libros/${id}`, { method: 'PUT', token, body: { titulo: 'El principito (edición revisada)' } });
  if (updated.status !== 200 || !updated.body.titulo.includes('revisada')) throw new Error('Update falló.');
  const db = require('../src/db/database');
  const stored = db.prepare('SELECT id, titulo, autor, anio FROM libros WHERE id = ?').get(id);
  if (!stored || stored.titulo !== updated.body.titulo) throw new Error('SQLite no contiene el cambio esperado.');
  db.close();
  // Cierra y vuelve a arrancar el proceso de Node antes de comprobar la misma fila.
  await stopServer();
  await startServer();
  const afterRestart = await request(`/libros/${id}`, { token });
  if (afterRestart.status !== 200 || afterRestart.body.titulo !== updated.body.titulo) throw new Error('El registro no persistió tras reiniciar Node.js.');
  const expired = jwt.sign({ sub: 'expired-check' }, jwtSecret, { algorithm: 'HS256', expiresIn: -1 });
  const expiredResponse = await request('/libros', { rawToken: expired });
  if (expiredResponse.status !== 401) throw new Error('Token vencido no devolvió 401.');
  const deleted = await request(`/libros/${id}`, { method: 'DELETE', token });
  const afterDelete = await request(`/libros/${id}`, { token });
  const freshDb = new (require('better-sqlite3'))(require('../src/config').dbFile);
  const rowAfterDelete = freshDb.prepare('SELECT id FROM libros WHERE id = ?').get(id);
  freshDb.close();
  if (deleted.status !== 200 || afterDelete.status !== 404 || rowAfterDelete) throw new Error('Delete no quedó reflejado en SQLite.');
  const result = {
    server: base, login: login.status, wrong_credentials: badLogin.status,
    unauthorized_no_token: denied.status, unauthorized_invalid_token: invalid.status,
    unauthorized_expired_token: expiredResponse.status, missing_required_field: missing.status,
    create: created.status, list: list.status, get_by_id: one.status, update: updated.status,
    direct_sql_after_update: stored, get_after_server_restart: afterRestart.status,
    delete: deleted.status, get_after_delete: afterDelete.status,
    direct_sql_after_delete: rowAfterDelete || null
  };
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  await stopServer();
})().catch(async error => {
  console.error(error.message);
  await stopServer();
  process.exit(1);
});
