const app = require('./app');
const { port } = require('./config');
require('./db/database');
app.listen(port, () => console.log(`API lista en http://localhost:${port}`));
