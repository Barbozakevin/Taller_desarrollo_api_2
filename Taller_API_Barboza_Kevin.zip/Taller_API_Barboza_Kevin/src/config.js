const path = require('node:path');
require('dotenv').config();

const jwtSecret = process.env.JWT_SECRET;
if (!jwtSecret || jwtSecret.length < 32 || jwtSecret.startsWith('REEMPLAZA_')) {
  throw new Error('JWT_SECRET debe ser un secreto local de al menos 32 caracteres.');
}

module.exports = {
  port: Number(process.env.PORT || 3000),
  dbFile: path.resolve(process.cwd(), process.env.DB_FILE || './data/taller.sqlite'),
  jwtSecret,
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '1h'
};
