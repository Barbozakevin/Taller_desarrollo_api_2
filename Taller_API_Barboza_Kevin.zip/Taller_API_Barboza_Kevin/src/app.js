const express = require('express');
const authRoutes = require('./routes/auth');
const librosRoutes = require('./routes/libros');
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '32kb' }));
app.get('/health', (_req, res) => res.status(200).json({ estado: 'ok' }));
app.use('/auth', authRoutes);
app.use('/libros', librosRoutes);
app.use((req, res) => res.status(404).json({ error: 'Ruta no encontrada.' }));
app.use((err, _req, res, _next) => {
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return res.status(400).json({ error: 'El cuerpo debe contener JSON válido.' });
  }
  console.error('Error inesperado:', err.message);
  return res.status(500).json({ error: 'Error interno del servidor.' });
});
module.exports = app;
