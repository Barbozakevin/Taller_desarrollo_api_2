const express = require('express');
const db = require('../db/database');
const requireAuth = require('../middleware/require-auth');
const router = express.Router();
router.use(requireAuth);

function validateBook(body, partial = false) {
  const errors = [];
  const has = (key) => Object.prototype.hasOwnProperty.call(body || {}, key);
  if (!partial || has('titulo')) {
    if (typeof body?.titulo !== 'string' || !body.titulo.trim() || body.titulo.trim().length > 160) errors.push('titulo debe ser texto de 1 a 160 caracteres');
  }
  if (!partial || has('autor')) {
    if (typeof body?.autor !== 'string' || !body.autor.trim() || body.autor.trim().length > 120) errors.push('autor debe ser texto de 1 a 120 caracteres');
  }
  if (has('anio') && body.anio !== null && (!Number.isInteger(body.anio) || body.anio < 0 || body.anio > 2100)) errors.push('anio debe ser un entero entre 0 y 2100 o null');
  if (partial && !['titulo', 'autor', 'anio'].some(has)) errors.push('envía al menos un campo editable');
  return errors;
}
function validId(value) { return /^\d+$/.test(value) && Number(value) > 0; }

router.post('/', (req, res) => {
  const errors = validateBook(req.body);
  if (errors.length) return res.status(400).json({ error: 'Datos inválidos.', details: errors });
  const result = db.prepare('INSERT INTO libros (titulo, autor, anio) VALUES (?, ?, ?)')
    .run(req.body.titulo.trim(), req.body.autor.trim(), req.body.anio ?? null);
  const libro = db.prepare('SELECT * FROM libros WHERE id = ?').get(result.lastInsertRowid);
  return res.status(201).json(libro);
});

router.get('/', (_req, res) => {
  const libros = db.prepare('SELECT * FROM libros ORDER BY id').all();
  return res.status(200).json(libros);
});

router.get('/:id', (req, res) => {
  if (!validId(req.params.id)) return res.status(400).json({ error: 'El identificador debe ser un entero positivo.' });
  const libro = db.prepare('SELECT * FROM libros WHERE id = ?').get(Number(req.params.id));
  if (!libro) return res.status(404).json({ error: 'Libro no encontrado.' });
  return res.status(200).json(libro);
});

router.put('/:id', (req, res) => {
  if (!validId(req.params.id)) return res.status(400).json({ error: 'El identificador debe ser un entero positivo.' });
  const errors = validateBook(req.body, true);
  if (errors.length) return res.status(400).json({ error: 'Datos inválidos.', details: errors });
  const current = db.prepare('SELECT * FROM libros WHERE id = ?').get(Number(req.params.id));
  if (!current) return res.status(404).json({ error: 'Libro no encontrado.' });
  const titulo = Object.hasOwn(req.body, 'titulo') ? req.body.titulo.trim() : current.titulo;
  const autor = Object.hasOwn(req.body, 'autor') ? req.body.autor.trim() : current.autor;
  const anio = Object.hasOwn(req.body, 'anio') ? req.body.anio : current.anio;
  db.prepare("UPDATE libros SET titulo = ?, autor = ?, anio = ?, updated_at = datetime('now') WHERE id = ?")
    .run(titulo, autor, anio, Number(req.params.id));
  return res.status(200).json(db.prepare('SELECT * FROM libros WHERE id = ?').get(Number(req.params.id)));
});

router.delete('/:id', (req, res) => {
  if (!validId(req.params.id)) return res.status(400).json({ error: 'El identificador debe ser un entero positivo.' });
  const result = db.prepare('DELETE FROM libros WHERE id = ?').run(Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: 'Libro no encontrado.' });
  return res.status(200).json({ mensaje: 'Libro eliminado.', id: Number(req.params.id) });
});

module.exports = router;
