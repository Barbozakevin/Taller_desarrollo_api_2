const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db/database');
const { jwtSecret, jwtExpiresIn } = require('../config');
const router = express.Router();

router.post('/login', (req, res) => {
  const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  if (!email || !password) {
    return res.status(400).json({ error: 'email y password son obligatorios.' });
  }
  const user = db.prepare('SELECT id, email, password_hash FROM users WHERE email = ?').get(email);
  const valid = user && bcrypt.compareSync(password, user.password_hash);
  if (!valid) return res.status(401).json({ error: 'Credenciales incorrectas.' });

  const token = jwt.sign({ sub: String(user.id), email: user.email }, jwtSecret, {
    algorithm: 'HS256', expiresIn: jwtExpiresIn
  });
  return res.status(200).json({ token, token_type: 'Bearer', expires_in: jwtExpiresIn });
});

module.exports = router;
