# Taller API REST de libros con JWT

API individual desarrollada con Node.js, Express 5, SQLite y JSON Web Tokens. La base se guarda en `data/taller.sqlite`, por lo que los datos sobreviven al reinicio del servidor. La API contiene el CRUD de libros y protege todas sus rutas con JWT. El endpoint de login compara el password con un hash bcrypt guardado en SQLite.

## Requisitos

- Node.js 20.19 o posterior (Express 5 requiere Node 18+, se recomienda Node 20 LTS o superior)
- NPM
- Postman
- SQLite no requiere instalar un servidor aparte; `better-sqlite3` usa un archivo local

## Instalación

En una terminal, dentro de la carpeta del proyecto:

```bash
npm install
```

Crea el archivo de configuración local:

```bash
cp .env.example .env
```

En Windows PowerShell puedes usar `Copy-Item .env.example .env`. Edita `.env` y reemplaza `JWT_SECRET` por una cadena aleatoria propia de al menos 32 caracteres. Define `ADMIN_EMAIL` y `ADMIN_PASSWORD` para la cuenta local; usa una contraseña de al menos 10 caracteres. No compartas el archivo `.env`.

Inicializa o actualiza la cuenta de prueba:

```bash
npm run init:admin
```

La contraseña no se guarda en claro, el script genera un hash bcrypt con costo 12. Arranca el servidor:

```bash
npm start
```

La API queda en `http://localhost:3000`. Comprueba que responde en `GET /health`.

## Flujo en Postman

1. Importa `postman/Taller_API_Libros.postman_collection.json`.
2. Ajusta la variable `baseUrl` si cambiaste el puerto.
3. Ejecuta **Login** con el mismo correo y contraseña definidos en `.env`. La prueba de la colección guarda el JWT localmente como variable `token`.
4. Ejecuta las solicitudes de `Libros CRUD`. La colección envía `Authorization: Bearer {{token}}`; `Crear libro` almacena su ID en `libroId`.
5. Ejecuta `GET lista`, `GET por ID`, `PUT`, `DELETE`, y `GET eliminado` para revisar respuestas 200/201/404. `Sin token`, `Token inválido`, `Login incorrecto` y `Validación obligatoria` cubren respuestas de error.
6. Reinicia el proceso con Ctrl+C y `npm start`, vuelve a iniciar sesión, consulta la lista y confirma que los registros siguen presentes.

En Postman, evita exportar o entregar una variable con token vigente. La colección incluida tiene `token` vacío.

## Rutas

| Método | Ruta | Respuesta habitual |
|---|---|---|
| POST | `/auth/login` | 200 y JWT; 401 si la contraseña no coincide |
| POST | `/libros` | 201 con el libro creado; 400 si faltan campos |
| GET | `/libros` | 200 con la lista |
| GET | `/libros/:id` | 200 o 404 |
| PUT | `/libros/:id` | 200 con el registro actualizado o 404 |
| DELETE | `/libros/:id` | 200 o 404 |

`titulo` y `autor` son obligatorios para crear; `anio` es opcional. En actualización se admite uno o más de esos campos. Las consultas SQL están parametrizadas.

## Comprobación directa de la persistencia

El archivo de datos está en `data/taller.sqlite` por defecto. Se puede abrir con DB Browser for SQLite o consultar con una herramienta SQLite:

```sql
SELECT id, titulo, autor, anio, created_at, updated_at FROM libros ORDER BY id;
SELECT id, email, length(password_hash) AS hash_length FROM users;
```

No consultes ni compartas el valor `password_hash` completo. Para demostrar el cambio, ejecuta `SELECT titulo, autor, anio FROM libros WHERE id = <ID>;` antes y después de `PUT`, reinicia el servidor y vuelve a consultar, y después de `DELETE` confirma que devuelve cero filas.

También puedes ejecutar la verificación automatizada con `.env` configurado. Detén primero cualquier servidor que ya use el puerto 3000; el verificador inicia la API, ejecuta las comprobaciones, reinicia Node para probar persistencia y luego lo cierra:

```bash
npm run verify
```

El flujo crea un libro de prueba, lee y actualiza el dato directamente en SQLite, comprueba autenticación, validación y borrado, y al final elimina ese registro de prueba. La evidencia JSON de una ejecución está en `evidence/resultados_verificacion.json` y el resumen está en `evidence/Taller_API_Evidencias.pdf`; el PDF deja espacios para que agregues las capturas requeridas de la interfaz Postman.

## Estructura

- `src/routes`: login y CRUD
- `src/middleware/require-auth.js`: firma, algoritmo y expiración del token
- `src/db/database.js`: tablas y conexión SQLite
- `scripts/init-admin.js`: inicialización de la cuenta hasheada
- `scripts/smoke-check.js`: flujo automatizado de comprobación
- `postman`: colección lista para importar

## Evidencias que debes capturar para el PDF final

1. Login exitoso (oculta o recorta el token antes de compartir).
2. POST creado con respuesta 201 y GET que muestra el registro.
3. Resultado de PUT y consulta SQL posterior mostrando el valor actualizado.
4. Reinicio del servidor y consulta persistente del mismo libro.
5. DELETE y consulta directa que muestre cero filas, junto con GET por ID que responda 404.
6. Una ruta sin token o token inválido con respuesta 401, y un POST incompleto con 400.

Las evidencias deben corresponder a tu ejecución local en Postman y SQLite. El PDF entregado junto al ZIP resume las verificaciones ejecutadas en este entorno; reemplázalo o complétalo con las capturas de tu propia revisión en vivo antes de entregar si tu docente exige pantallas reales de Postman.
